const classNotClear = ['linh-style-color']
module.exports = {
  classNotClear
}
