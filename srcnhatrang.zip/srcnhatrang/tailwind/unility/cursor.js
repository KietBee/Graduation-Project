const Cursor = {
  auto: 'auto',
  default: 'default',
  pointer: 'pointer',
  wait: 'wait',
  text: 'text',
  move: 'move',
  help: 'help',
  'not-allowed': 'not-allowed'
}
module.exports = {
  Cursor
}
