const lineHeight = {
  none: '1',
  tight: '1.25',
  snug: '1.375',
  normal: '1.5',
  relaxed: '1.625',
  loose: '2',
  3: '.75',
  4: '1',
  5: '1.25',
  6: '1.5',
  7: '1.75',
  8: '2',
  9: '2.25',
  10: '2.5'
}
module.exports = {
  lineHeight
}
