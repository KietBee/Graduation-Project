const listStyleType = {
  none: 'none',
  disc: 'disc',
  decimal: 'decimal'
}
module.exports = {
  listStyleType
}
