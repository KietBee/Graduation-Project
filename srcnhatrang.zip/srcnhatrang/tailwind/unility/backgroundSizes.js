const backgroundSizes = {
  'auto': 'auto',
  'cover': 'cover',
  'contain': 'contain'
}
module.exports = {
  backgroundSizes
}
