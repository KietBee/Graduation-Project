<h2>Hi <?php echo e($name); ?></h2>
<p>
    tesst neeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeeee
</p><?php /**PATH D:\Graduation-Project\srcnhatrang\resources\views/test-email.blade.php ENDPATH**/ ?>