
<!-- resources/views/layouts/app.blade.php -->
 


<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
  
  <?php echo app('Illuminate\Foundation\Vite')(['resources/assets/styles/app.scss', 'resources/assets/scripts/app.js']); ?>
  <body>
    <?php echo $__env->make('layouts.navigation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  
  <div id="wrapper" class="wrapper has-animation">
    
    <main id="main-content">
      <?php echo $__env->yieldContent('content'); ?>
    </main>
    
    </div>
  </body>
</html>

<?php /**PATH D:\Graduation-Project\srcnhatrang\resources\views/layouts/admin-app.blade.php ENDPATH**/ ?>