<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Pet extends Model
{
    use HasFactory;

    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'pets';

    /**
     * The primary key associated with the table.
     *
     * @var string
     */
    protected $primaryKey = 'pet_id';

    /**
     * Indicates if the ids are auto-incrementing.
     *
     * @var bool
     */
    public $incrementing = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'pet_id',
        'primary_color_id',
        'age_id',
        'size_id',
        'breed_id',
        'pet_name',
        'gender',
        'description',
        'health_status',
        'rescued_at',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array
     */
    protected $casts = [
        'gender' => 'boolean',
        'rescued_at' => 'datetime',
    ];
}
