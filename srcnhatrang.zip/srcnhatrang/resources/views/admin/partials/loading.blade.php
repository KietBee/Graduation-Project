<!-- BEGIN LOADDING -->
<div id="loadding-page" class="module loadding-page fixed hidden inset-0 z-9999 bg-brown-100">
    <div class="loader fixed transform-center-middle z-9999">
        <div class="spinner w-25 h-25 mx-auto relative">
            <div class="donut absolute inset-0 w-full h-full rounded-full"></div>
        </div>
    </div>
</div>
<!-- END LOADDING -->
