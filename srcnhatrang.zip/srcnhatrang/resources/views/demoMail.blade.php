<!DOCTYPE html>
<html>
<head>
 <title>Laravel 11 Send Email Example</title>
</head>
<body>
 <h1>This is first email in Laravel 11</h1>
 <p>Hello,  Laravel Developer</p>
</body>
</html> 