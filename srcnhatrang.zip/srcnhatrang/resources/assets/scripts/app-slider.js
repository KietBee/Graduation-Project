import 'slick-carousel/slick/slick'
import 'modules/SliderDemo'
// ADA
import 'modules/ModCarouselSlide'
